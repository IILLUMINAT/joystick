--https://t.me/solar2dBox
print("https://t.me/solar2dBox")
local waterMark = display.newText("https://t.me/solar2dBox",display.contentCenterX, display.contentCenterY - display.actualContentHeight / 2.3, native.systemFont, 30)

physics = require("physics")
physics.start()
cameraGroup = display.newGroup()

for i = 1, 100 do
    local ball = display.newCircle(cameraGroup, math.random(-display.contentWidth, display.contentWidth), math.random(-display.contentWidth, display.contentWidth), display.contentWidth / 40)
    physics.addBody(ball, "dynamic", { friction=0.1, bounce=0.3 } )
    ball.gravityScale = 0
    ball:setFillColor(math.random(0, 255) / 100, math.random(0, 255) / 100, math.random(0, 255) / 100)
end

otherPlayer = display.newRect(cameraGroup, display.contentCenterX + display.contentWidth / 2, display.contentCenterY, display.contentWidth / 15, display.contentWidth / 15)
physics.addBody(otherPlayer, "dynamic", { friction=0.5, bounce=0.3} )
otherPlayer.gravityScale = 0

require("joy")
waterMark:toFront()