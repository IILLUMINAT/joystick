application={content={fps=60,width=720,height=1280,scale="adaptive"}}
