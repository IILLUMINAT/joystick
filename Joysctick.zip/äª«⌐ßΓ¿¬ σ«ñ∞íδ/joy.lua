--создаём игрока

player = display.newRect(cameraGroup, display.contentCenterX, display.contentCenterY, display.contentWidth / 10, display.contentWidth / 10)
player:setFillColor(1, 0.84, 0)
physics.addBody( player, "dynamic", { friction=0.5, bounce=0.3 } )
player.gravityScale = 0
player.isFixedRotation = true


--объявляем переменные
local isJoyActive = false
local joyVectorX = 0
local joyVectorY = 0
local speed = 6

--слушатель
local listenerJoyFunc = function(event)
    if event.phase == "began" or event.phase == "moved" then
        local x1 = event.x
        local y1 = event.y
        local distance = math.sqrt((x1 - joyBackground.x)^2 + (y1 - joyBackground.y)^2)
        distance = distance > display.contentWidth / 15 and display.contentWidth / 15 or distance
        local vector = math.atan2(x1 - joyBackground.x, y1 - joyBackground.y)
        joy.x = math.sin(vector) * distance + joyBackground.x
        joy.y = math.cos(vector) * distance + joyBackground.y

        joyVectorX = math.sin(vector)
        joyVectorY = math.cos(vector)
        isJoyActive = true
        
        display.getCurrentStage():setFocus(event.target, event.id)
    elseif event.phase == "ended" then
        display.getCurrentStage():setFocus(event.target, nil)
        joy.x = joyBackground.x
        joy.y = joyBackground.y
        
        joyVectorX = 0
        joyVectorY = 0
        isJoyActive = false
    end
end


--перемещение игрока и камеры
local function movePlayer()
    if isJoyActive then
        player.x = player.x + joyVectorX * speed
        player.y = player.y + joyVectorY * speed
        player:toFront()
    end
    cameraGroup.x = -player.x + display.actualContentWidth / 2
    cameraGroup.y = -player.y + display.actualContentHeight / 2
end


--создание джойстика
joyBackground = display.newCircle((display.contentCenterX - display.actualContentWidth / 2) + display.contentWidth / 7, (display.contentCenterY + display.actualContentHeight / 2) - display.contentWidth / 7, display.contentWidth / 15)
joyBackground.alpha = 0.5
joy = display.newCircle(joyBackground.x, joyBackground.y, display.contentWidth / 30)
joy.alpha = 0.7

joy:addEventListener("touch", listenerJoyFunc)
Runtime:addEventListener("enterFrame", movePlayer)